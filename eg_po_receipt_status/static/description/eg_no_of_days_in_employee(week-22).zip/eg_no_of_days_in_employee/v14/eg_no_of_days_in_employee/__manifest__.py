{
    'name': 'Number Of Days in Employee',
    'version': '14.0',
    'category': 'Employee',
    'summery': 'Number Of Days in Employee',
    'author': '',
    'depends': ['hr'],
    'data': [
        'views/hr_employee.xml',
    ],
    'qweb': [],
    'images': [],
    'license': "OPL-1",
    'installable': True,
    'application': True,
    'auto_install': False,
}